import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: '多模态建筑能耗分析平台',
  description: '基于 MiMo Vision 的智能建筑能耗分析',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  )
}
