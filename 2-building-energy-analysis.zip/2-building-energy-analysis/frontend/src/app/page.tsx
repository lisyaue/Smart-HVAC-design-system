'use client'

import { useState, useRef } from 'react'

export default function Home() {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string>('')
  const [analysis, setAnalysis] = useState<any>(null)
  const [simulation, setSimulation] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const handleFile = (f: File) => {
    setFile(f)
    setPreview(URL.createObjectURL(f))
    setAnalysis(null)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    const f = e.dataTransfer.files[0]
    if (f?.type.startsWith('image/')) handleFile(f)
  }

  const handleAnalyze = async () => {
    if (!file) return
    setLoading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/analyze/image', { method: 'POST', body: formData })
      const data = await res.json()
      setAnalysis(data.analysis)

      // 自动运行能耗模拟
      const simRes = await fetch('/api/simulate/energy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          city: '北京',
          building_type: data.analysis.building_type || '办公',
          area: data.analysis.estimated_area || 1000,
        }),
      })
      const simData = await simRes.json()
      setSimulation(simData.simulation)
    } catch (err) {
      alert('分析失败: ' + err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      <header className="header">
        <h1>🏢 多模态建筑能耗分析平台</h1>
        <p>上传建筑照片 → MiMo Vision 智能识别 → 能耗模拟分析</p>
      </header>
      <div className="container">
        {/* 上传区域 */}
        <div className="card">
          <h2>📸 上传建筑图像</h2>
          <div
            className="upload-zone"
            onClick={() => fileRef.current?.click()}
            onDrop={handleDrop}
            onDragOver={e => e.preventDefault()}
          >
            {preview ? (
              <img src={preview} alt="preview" className="preview" />
            ) : (
              <p>📷 点击或拖拽上传建筑照片</p>
            )}
            <input ref={fileRef} type="file" accept="image/*" hidden
              onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />
          </div>
          {file && (
            <button className="btn" onClick={handleAnalyze} disabled={loading} style={{ marginTop: '1rem' }}>
              {loading ? '⏳ MiMo 分析中...' : '🤖 开始分析'}
            </button>
          )}
        </div>

        {/* 分析结果 */}
        {analysis && (
          <div className="card">
            <h2>🔍 MiMo Vision 分析结果</h2>
            <div className="grid">
              <div className="stat"><div className="value">{analysis.building_type}</div><div className="label">建筑类型</div></div>
              <div className="stat"><div className="value">{analysis.floors}F</div><div className="label">估计楼层</div></div>
              <div className="stat"><div className="value">{analysis.estimated_area}m²</div><div className="label">估计面积</div></div>
              <div className="stat"><div className="value">{analysis.energy_rating}</div><div className="label">节能等级</div></div>
            </div>
            <table style={{ marginTop: '1rem' }}>
              <tbody>
                <tr><td>🧱 墙体材料</td><td>{analysis.wall_material}</td></tr>
                <tr><td>🪟 窗户类型</td><td>{analysis.window_type}</td></tr>
                <tr><td>🏠 屋顶类型</td><td>{analysis.roof_type}</td></tr>
                <tr><td>🔥 保温层</td><td>{analysis.insulation}</td></tr>
              </tbody>
            </table>
            {analysis.recommendations && (
              <>
                <h3 style={{ marginTop: '1rem', marginBottom: '0.5rem' }}>💡 改进建议</h3>
                <ul className="recommendations">
                  {analysis.recommendations.map((r: string, i: number) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </>
            )}
          </div>
        )}

        {/* 能耗模拟 */}
        {simulation && (
          <div className="card">
            <h2>📊 能耗模拟结果</h2>
            <div className="grid">
              <div className="stat"><div className="value">{simulation.annual.total_kwh}</div><div className="label">年总能耗 (kWh)</div></div>
              <div className="stat"><div className="value">{simulation.annual.per_m2}</div><div className="label">单位面积 (kWh/m²)</div></div>
              <div className="stat"><div className="value">{simulation.carbon.total_kg}</div><div className="label">碳排放 (kgCO₂)</div></div>
              <div className="stat"><div className="value">{simulation.cost.annual_cost}</div><div className="label">年费用 (元)</div></div>
            </div>
            <h3 style={{ marginTop: '1.5rem', marginBottom: '0.5rem' }}>📅 月度能耗分布</h3>
            <table>
              <thead>
                <tr><th>月份</th><th>供暖</th><th>制冷</th><th>照明</th><th>设备</th><th>合计</th></tr>
              </thead>
              <tbody>
                {simulation.monthly.map((m: any) => (
                  <tr key={m.month}>
                    <td>{m.month}月</td>
                    <td>{m.heating}</td>
                    <td>{m.cooling}</td>
                    <td>{m.lighting}</td>
                    <td>{m.equipment}</td>
                    <td><strong>{m.total}</strong></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  )
}
