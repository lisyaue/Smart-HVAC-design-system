# 🏢 多模态建筑能耗分析平台

> 结合 MiMo Vision 的建筑图像识别与能耗模拟

[![Python](https://img.shields.io/badge/Python-3.11+-blue.svg)](https://python.org)
[![Next.js](https://img.shields.io/badge/Next.js-14-black.svg)](https://nextjs.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110-009688.svg)](https://fastapi.tiangolo.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![MiMo](https://img.shields.io/badge/MiMo-V2.5_Vision-FF6900.svg)](https://platform.xiaomimimo.com)

## ✨ 功能特性

- 📸 **图像识别** — 上传建筑照片，MiMo Vision 自动识别围护结构
- 🌡️ **能耗模拟** — 基于度日法的全年能耗预测
- 📊 **可视化分析** — ECharts 图表展示能耗分布
- 📝 **智能报告** — MiMo Pro 生成专业分析报告
- 🌤️ **气象集成** — 自动获取城市气象数据

## 🏛️ 系统架构

```
┌──────────────────────────────────────┐
│         Next.js Frontend             │
│  ┌────────┐ ┌──────┐ ┌────────────┐ │
│  │图像上传│ │分析  │ │ 报告下载   │ │
│  │& 预览  │ │图表  │ │            │ │
│  └───┬────┘ └──┬───┘ └─────┬──────┘ │
└──────┼─────────┼───────────┼─────────┘
       ▼         ▼           ▼
┌──────────────────────────────────────┐
│         FastAPI Backend              │
│  ┌────────┐ ┌────────┐ ┌──────────┐ │
│  │MiMo    │ │能耗    │ │ 报告     │ │
│  │Vision  │ │模拟器  │ │ 生成器   │ │
│  └────────┘ └────────┘ └──────────┘ │
└──────────────────────────────────────┘
```

## 🚀 快速开始

```bash
# 后端
cd backend && pip install -r requirements.txt
export MIMO_API_KEY="your-key"
uvicorn main:app --reload --port 8001

# 前端
cd frontend && npm install && npm run dev
```

## 📡 API

| 端点 | 方法 | 说明 |
|------|------|------|
| `/api/analyze/image` | POST | 图像识别分析 |
| `/api/simulate/energy` | POST | 能耗模拟 |
| `/api/report/generate` | POST | 生成报告 |
| `/api/weather/{city}` | GET | 气象数据 |

## 📄 License

MIT
