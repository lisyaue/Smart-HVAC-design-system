"""简化能耗模拟引擎

基于度日法（Degree-Day Method）进行全年能耗估算
"""
from typing import Optional


# 城市度日数 & 气象数据
CITY_DATA = {
    "北京": {"hdd18": 2680, "cdd26": 2520, "avg_temp": 12.9, "solar_radiation": 4800},
    "上海": {"hdd18": 1560, "cdd26": 1640, "avg_temp": 16.1, "solar_radiation": 4200},
    "广州": {"hdd18": 350, "cdd26": 1100, "avg_temp": 22.3, "solar_radiation": 4400},
    "深圳": {"hdd18": 180, "cdd26": 980, "avg_temp": 23.0, "solar_radiation": 4600},
    "成都": {"hdd18": 1420, "cdd26": 1120, "avg_temp": 16.2, "solar_radiation": 3200},
    "武汉": {"hdd18": 1880, "cdd26": 1780, "avg_temp": 16.5, "solar_radiation": 4100},
    "西安": {"hdd18": 2280, "cdd26": 1680, "avg_temp": 13.3, "solar_radiation": 4300},
}

# 建筑能耗指标 (kWh/m²·年)
BUILDING_ENERGY_INDEX = {
    "住宅": {"heating": 30, "cooling": 20, "lighting": 15, "equipment": 20},
    "办公": {"heating": 25, "cooling": 30, "lighting": 25, "equipment": 40},
    "商业": {"heating": 20, "cooling": 35, "lighting": 40, "equipment": 30},
    "酒店": {"heating": 35, "cooling": 25, "lighting": 20, "equipment": 25},
    "学校": {"heating": 30, "cooling": 15, "lighting": 20, "equipment": 15},
}


def simulate_energy(
    city: str,
    building_type: str,
    area: float,
    wall_k: float = 0.6,
    window_k: float = 2.8,
    cop: float = 4.0,
    lighting_efficiency: float = 0.7,
) -> dict:
    """
    全年能耗模拟

    基于度日法 + 建筑修正系数
    """
    city_info = CITY_DATA.get(city, CITY_DATA["北京"])
    energy_index = BUILDING_ENERGY_INDEX.get(building_type, BUILDING_ENERGY_INDEX["办公"])

    # 墙体修正系数（基准 K=1.0）
    wall_factor = wall_k / 1.0
    # 窗户修正系数（基准 K=3.0）
    window_factor = window_k / 3.0
    # COP 修正（基准 COP=3.0）
    cop_factor = 3.0 / cop

    # 供暖能耗 (kWh/年)
    heating_dd = city_info["hdd18"]
    heating_base = energy_index["heating"] * area
    heating_energy = heating_base * wall_factor * cop_factor * (heating_dd / 2500)

    # 制冷能耗
    cooling_dd = city_info["cdd26"]
    cooling_base = energy_index["cooling"] * area
    cooling_energy = cooling_base * window_factor * cop_factor * (cooling_dd / 2000)

    # 照明能耗
    lighting_energy = energy_index["lighting"] * area * lighting_efficiency

    # 设备能耗
    equipment_energy = energy_index["equipment"] * area

    # 总能耗
    total_energy = heating_energy + cooling_energy + lighting_energy + equipment_energy

    # 碳排放 (kgCO2/kWh，中国电网平均排放因子)
    carbon_factor = 0.5810
    carbon_emission = total_energy * carbon_factor

    # 月度分布（简化）
    monthly = _calculate_monthly_distribution(
        heating_energy, cooling_energy, lighting_energy, equipment_energy
    )

    return {
        "annual": {
            "total_kwh": round(total_energy, 0),
            "heating_kwh": round(heating_energy, 0),
            "cooling_kwh": round(cooling_energy, 0),
            "lighting_kwh": round(lighting_energy, 0),
            "equipment_kwh": round(equipment_energy, 0),
            "per_m2": round(total_energy / area, 1),
        },
        "carbon": {
            "total_kg": round(carbon_emission, 0),
            "per_m2": round(carbon_emission / area, 1),
        },
        "monthly": monthly,
        "cost": {
            "electricity_price": 0.55,  # 元/kWh
            "annual_cost": round(total_energy * 0.55, 0),
            "per_m2_cost": round(total_energy * 0.55 / area, 1),
        },
    }


def _calculate_monthly_distribution(heating, cooling, lighting, equipment):
    """计算月度能耗分布"""
    # 供暖月份权重（北方11-3月）
    heating_weights = [0.15, 0.12, 0.08, 0.03, 0, 0, 0, 0, 0, 0.05, 0.15, 0.18]
    # 制冷月份权重（6-9月）
    cooling_weights = [0, 0, 0, 0.03, 0.08, 0.18, 0.25, 0.25, 0.15, 0.06, 0, 0]
    # 照明/设备均匀分布
    even_weights = [1/12] * 12

    months = []
    for i in range(12):
        h = heating * heating_weights[i]
        c = cooling * cooling_weights[i]
        l = lighting * even_weights[i]
        e = equipment * even_weights[i]
        months.append({
            "month": i + 1,
            "heating": round(h, 0),
            "cooling": round(c, 0),
            "lighting": round(l, 0),
            "equipment": round(e, 0),
            "total": round(h + c + l + e, 0),
        })
    return months
