"""MiMo Vision 图像分析客户端"""
import os
import httpx
import base64

MIMO_BASE_URL = os.getenv("MIMO_BASE_URL", "https://token-plan-cn.xiaomimimo.com/v1")
MIMO_API_KEY = os.getenv("MIMO_API_KEY", "")


async def analyze_building_image(image_bytes: bytes, filename: str) -> dict:
    """使用 MiMo Vision 分析建筑图像"""
    if not MIMO_API_KEY:
        return _mock_analysis()

    image_b64 = base64.b64encode(image_bytes).decode()
    mime = "image/jpeg" if filename.endswith((".jpg", ".jpeg")) else "image/png"

    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(
            f"{MIMO_BASE_URL}/chat/completions",
            headers={
                "Authorization": f"Bearer {MIMO_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": "mimo-v2.5-vision",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": """请分析这张建筑图像，识别以下信息并以JSON格式返回：
{
  "building_type": "建筑类型（住宅/办公/商业/工业）",
  "floors": "估计楼层数",
  "wall_material": "推测墙体材料",
  "window_type": "推测窗户类型",
  "roof_type": "屋顶类型",
  "insulation": "是否有保温层（是/否/不确定）",
  "orientation": "推测主要朝向",
  "estimated_area": "估计建筑面积(m²)",
  "energy_rating": "预估节能等级(A/B/C/D)",
  "recommendations": ["改进建议1", "改进建议2"]
}"""
                            },
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:{mime};base64,{image_b64}"}
                            }
                        ]
                    }
                ],
                "max_tokens": 1000,
            },
        )
        response.raise_for_status()
        data = response.json()
        content = data["choices"][0]["message"]["content"]

        # 尝试解析 JSON
        import json
        try:
            # 提取 JSON 部分
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                json_str = content.split("```")[1].split("```")[0]
            else:
                json_str = content
            return json.loads(json_str.strip())
        except:
            return {"raw_response": content}


def _mock_analysis() -> dict:
    """无 API Key 时的模拟数据"""
    return {
        "building_type": "办公建筑",
        "floors": 6,
        "wall_material": "加气混凝土砌块",
        "window_type": "双层中空玻璃",
        "roof_type": "平屋顶（有保温）",
        "insulation": "是",
        "orientation": "南",
        "estimated_area": 3000,
        "energy_rating": "B",
        "recommendations": [
            "建议将窗户升级为三层Low-E玻璃，可降低约15%空调负荷",
            "建议增加外墙保温厚度至80mm，可进一步降低传热系数",
            "建议安装智能遮阳系统，减少夏季太阳辐射得热",
        ],
    }
