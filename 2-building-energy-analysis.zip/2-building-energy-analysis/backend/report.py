"""MiMo Pro 报告生成"""
import os
import httpx

MIMO_BASE_URL = os.getenv("MIMO_BASE_URL", "https://token-plan-cn.xiaomimimo.com/v1")
MIMO_API_KEY = os.getenv("MIMO_API_KEY", "")


async def generate_energy_report(
    city: str,
    building_type: str,
    area: float,
    analysis_result: dict,
    simulation_result: dict,
) -> str:
    """使用 MiMo 生成能耗分析报告"""
    if not MIMO_API_KEY:
        return _mock_report(city, building_type, area, simulation_result)

    prompt = f"""你是一位建筑节能专家。请根据以下数据生成专业的建筑能耗分析报告。

## 建筑信息
- 城市：{city}
- 类型：{building_type}
- 面积：{area} m²

## AI 图像分析结果
{analysis_result}

## 能耗模拟结果
- 年总能耗：{simulation_result['annual']['total_kwh']} kWh
- 单位面积能耗：{simulation_result']['annual']['per_m2']} kWh/m²·年
- 供暖能耗：{simulation_result']['annual']['heating_kwh']} kWh
- 制冷能耗：{simulation_result']['annual']['cooling_kwh']} kWh
- 碳排放：{simulation_result']['carbon']['total_kg']} kgCO₂/年
- 年运行费用：{simulation_result']['cost']['annual_cost']} 元

请生成包含以下章节的报告（Markdown格式）：
1. 项目概述
2. 建筑围护结构分析
3. 能耗模拟结果
4. 月度能耗分布分析
5. 节能潜力评估
6. 改进建议
7. 经济性分析"""

    async with httpx.AsyncClient(timeout=120) as client:
        response = await client.post(
            f"{MIMO_BASE_URL}/chat/completions",
            headers={
                "Authorization": f"Bearer {MIMO_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": "mimo-v2.5-pro",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.5,
                "max_tokens": 4096,
            },
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]


def _mock_report(city, building_type, area, sim):
    return f"""# {city}{building_type}建筑能耗分析报告

## 1. 项目概述
本报告对位于{city}的{building_type}建筑进行能耗分析，建筑面积{area}m²。

## 2. 能耗模拟结果
- 年总能耗：{sim['annual']['total_kwh']} kWh
- 单位面积指标：{sim['annual']['per_m2']} kWh/m²·年
- 碳排放强度：{sim['carbon']['per_m2']} kgCO₂/m²·年

## 3. 改进建议
1. 升级围护结构保温
2. 优化空调系统COP
3. 采用高效照明系统

> 本报告由 MiMo V2.5 Pro 生成
"""
