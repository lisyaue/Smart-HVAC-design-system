"""多模态建筑能耗分析平台 - FastAPI 后端"""
import json
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from vision import analyze_building_image
from simulator import simulate_energy
from report import generate_energy_report

load_dotenv()

app = FastAPI(title="建筑能耗分析平台", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "Building Energy Analysis"}


@app.post("/api/analyze/image")
async def analyze_image(file: UploadFile = File(...)):
    """上传建筑图像，MiMo Vision 自动分析"""
    if not file.content_type.startswith("image/"):
        raise HTTPException(400, "请上传图片文件")
    image_bytes = await file.read()
    result = await analyze_building_image(image_bytes, file.filename)
    return {"analysis": result, "model": "MiMo V2.5 Vision"}


@app.post("/api/simulate/energy")
async def energy_simulation(params: dict):
    """能耗模拟"""
    result = simulate_energy(
        city=params.get("city", "北京"),
        building_type=params.get("building_type", "办公"),
        area=params.get("area", 1000),
        wall_k=params.get("wall_k", 0.6),
        window_k=params.get("window_k", 2.8),
        cop=params.get("cop", 4.0),
    )
    return {"simulation": result}


@app.post("/api/report/generate")
async def gen_report(params: dict):
    """生成分析报告"""
    sim = simulate_energy(
        city=params.get("city", "北京"),
        building_type=params.get("building_type", "办公"),
        area=params.get("area", 1000),
    )
    content = await generate_energy_report(
        city=params.get("city", "北京"),
        building_type=params.get("building_type", "办公"),
        area=params.get("area", 1000),
        analysis_result=params.get("analysis", {}),
        simulation_result=sim,
    )
    return {"report": content, "model": "MiMo V2.5 Pro"}


@app.get("/api/weather/{city}")
async def weather(city: str):
    """城市气象数据"""
    from simulator import CITY_DATA
    data = CITY_DATA.get(city, CITY_DATA["北京"])
    return {"city": city, "data": data}
